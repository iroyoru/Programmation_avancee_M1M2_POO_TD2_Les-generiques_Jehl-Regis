/* 1/ une classe g�n�rique a pour avantage de s'ex�cuter sur n'importe quel type sans qu'il soit oblig� de le d�clarer avant l'instanciation 
 * 2/ 
 */


import java.time.LocalDate;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Cr�ation d'une liste de personnes
		Personne JW,MS,LJ,GM,WB;
		JW = new Personne("Wayne","John",LocalDate.of(1907, 5, 26));
		MS = new Personne("McQueen","Steeve",LocalDate.of(1930, 3, 24));
		LJ = new Personne("Lennon","John",LocalDate.of(1940, 10, 9));
		GM = new Personne("Gibson","Mel",LocalDate.of(1956, 1, 3));
		WB = new Personne("Willis","Bruce",LocalDate.of(1955, 3, 19));
		
		
		// cr�ation d'une liste g�n�rique
		ListGenerique<String> lString = new ListGenerique<String>();
		
		
		lString.add("Hello");
		lString.add("World");
		lString.add("Have a");
		lString.add("Good day");
		lString.add("(^_^) !");
		
	
		
		System.out.println(lString);
		
		
		

		
	
		
		

	}
	
	// fonction menu
	
	static void Menu(ListGenerique l){
		
		
		
	}
	


}

