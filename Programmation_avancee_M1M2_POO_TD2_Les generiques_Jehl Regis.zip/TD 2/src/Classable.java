

// cette interface devra �tre impl�ment�e par les classes pour lesquells un classement des instances est envisag�

public interface Classable {
	
	// cette m�thode pourra �tre appel�e pour comparer l'isntance courante 
	// avec celle recue en param�tre la m�thode retourne un entier dont la valeur
	// d�pend des r�gles suviantes : 
	// 1 si l'isntance o1 sup�rieur � o2
	// 0 si les deux isntaces sont �gales
	// -1 si l'instance o1 est inf�rieur � o2
	// -99 si la comparaison est impossible
	
	int compare (Object o);
	
	default boolean isInferieur(Object o){
		return false;
	}
	default boolean isSupererieur(Object o){
		return false;
	}
	
	public static final int INFERIEUR=-1;
	public static final int EGAL=0;
	public static final int SUPERIEUR=1;
	public static final int ERREUR=-99;
	
	public static Classable[] tri(Classable[] tablo){
		
		return null;
		
	}
	



}