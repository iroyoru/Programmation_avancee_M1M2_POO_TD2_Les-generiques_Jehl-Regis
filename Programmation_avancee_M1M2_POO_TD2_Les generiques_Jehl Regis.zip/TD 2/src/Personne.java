


import java.time.LocalDate;
import java.time.temporal.ChronoUnit;


public class Personne implements Classable {
	
	private String nom;
	private String prenom;
	private LocalDate date_naiss;
	//champ priv� repr�sentant le num�ro de la personne
	private int numero;
	//champ statique priv� repr�sentant le compteur de Personnes
	private static int nbInstances;

	
// M�thodes get :
	
public String getNom(){
	return nom;
}

public String getPrenom(){
	return prenom;
}

public LocalDate getDateNaiss(){
	return date_naiss;
	}

public int getNumero(){
	return numero;
}

public int getNbInstances(){
	return nbInstances;
}



// M�thodes set : 

public void setNom(String imput_nom){
	nom = imput_nom.toUpperCase();
}

public void setPrenom(String imput_prenom){
	prenom = imput_prenom.toLowerCase();
}

public void setDateNaiss(LocalDate imput_date_naiss){
	date_naiss = imput_date_naiss;
}


// Constructeur

public Personne(){
	
	nom="";
	prenom="";
	date_naiss=null;
	//Creation d'une nouvelle personne donc incr�mentation du compteur
	nbInstances ++;
	//affectation � la nouvelle personne de son num�ro
	numero=nbInstances;
	
}

public Personne(String input_nom, String input_prenom, LocalDate input_date_naiss){
	
	nom=input_nom;
	prenom=input_prenom;
	date_naiss = input_date_naiss;
	
}


// M�thodes diverses : 

public long calculAge()
	{
	return date_naiss.until(LocalDate.now(), ChronoUnit.YEARS);
	}


// M�thodes affichages : 

@Deprecated
public void affichage(){
	System.out.println("Nom : "+ getNom());
	System.out.println("Pr�nom : "+ getPrenom());
	System.out.println("Date de naissance : " + calculAge());
	}

public void affichage(Boolean majuscule){
	if (majuscule) {
		System.out.println("Nom : "+ nom.toUpperCase());
		System.out.println("Pr�nom : " + prenom.toUpperCase());
		System.out.println("Age : "+calculAge());
		}
	else{
		System.out.println("Nom : "+nom.toLowerCase());
		System.out.println("Pr�nom : "+prenom.toLowerCase());
		System.out.println("Age : " + calculAge());
		}
	}

public void affichagefr(Boolean francais){
	if (francais) {
		System.out.println("Nom : "+ nom);
		System.out.println("Pr�nom : " + prenom);
		System.out.println("Age : "+calculAge());
		}
	else{
		System.out.println("Name : "+nom);
		System.out.println("Surname : "+prenom);
		System.out.println("Age : " + calculAge());
		}
	}
	
public int compare (Object o){
	
	Personne p;
	if ( o instanceof Personne){
		p=(Personne)o;
	}
	else return Classable.ERREUR;
	
	if(getNom().compareTo(p.getNom())<0){
		return Classable.INFERIEUR;
	}
	if(getNom().compareTo(p.getNom())>0){
		return Classable.SUPERIEUR;
	}
	
	return Classable.EGAL;
	
}

public static Personne ChercheNom (Personne[] tab,String nom ){

	for(Personne p:tab){
		if (p.getNom().equals(nom)){
			return p;
			}
		}
	return null;
	}

public static Personne CherchePrenom (Personne[] tab,String prenom ){

	for(Personne p:tab){
		if (p.getPrenom().equals(prenom)){
			return p;
			}
		}
	return null;
	}

public static Personne CherchePrenom (Personne[] tab,long Age ){

	for(Personne p:tab){
		if (p.calculAge()==Age){
			return p;
			}
		}
	return null;
	}

public static Personne ChercheNomPrenom (Personne[] tab,String nom, String prenom ){

	for(Personne p:tab){
		if (p.getNom().equals(nom)&&p.getPrenom().equals(prenom)){
			return p;
			}
		}
	return null;
	}

/*public static Personne recherchePersonne(Personne[] tablo, ComparateurPersonne cp){
	
	for (Personne p:tablo){
		if(cp.isIdentique(p)){
			return p;
		}
	}
	return null;
}*/

public String toString(){
	
	return this.getNom() + '|' +
			this.getPrenom() + '|' +
			this.calculAge();
			
}
}

	









