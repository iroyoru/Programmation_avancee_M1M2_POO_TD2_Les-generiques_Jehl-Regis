import java.util.ArrayList;

public class ListGenerique < E > {
	
	// g�n�ration de la liste
	private ArrayList<Object> listGenerique;
	
	// Constructeurs
	
	public ListGenerique (){
		this.listGenerique = null;
	}
	
	// set, get

	public void setListGenerique(ArrayList<Object> L){
		this.listGenerique = L;
		
		
	}
	
	public ArrayList<Object> getListGenerique(){
		return this.listGenerique;
	}
	
	// Fonctions
	
	public void add(Object o){
		
		listGenerique.add(o);
	}

	public void remove(Object o){
		listGenerique.remove(o);
	}
	
	public Object first(){
		return listGenerique.get(0);
	}
	
	public Object last(){
		return listGenerique.get(listGenerique.size()-1);
	}

	public int nbElem(){
		return listGenerique.size();
	}
	
	public Object next(Object objetBase){
		if (listGenerique.indexOf(objetBase)<listGenerique.size())
			return listGenerique.get(listGenerique.indexOf(objetBase)+1);
		else 
			return this.last();
	}
	
	public Object prev(Object objetBase){
		
		if (listGenerique.indexOf(objetBase)>0 )
			return listGenerique.get(listGenerique.indexOf(objetBase)-1);
		else 
			return this.first();
	}
}
